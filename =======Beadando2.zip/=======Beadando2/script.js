const KepekLista = [
    "axolt", "capibara", "golya", "kameleon", "lajhar", "lama", "macska", "mokus",
    "nyuszi", "oroszlan", "panda", "papagaj", "pava", "roka", "suni", "tehen"
  ];
  
  let flippedCards = []; 
  let matchedCards = 0; //hany db eltalalt kartya
  let totalCards = 0; //osszes katyak szama
  let timer = 0; 
  let interval = null;
  let hibak = 0;
  let hasznaltRevealOne = false;
  let hasznaltRevealAll = false;
  
  // adatok bekerese
  document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('adatok-form')) {
      document.getElementById('adatok-form').addEventListener('submit', function (e) {
        e.preventDefault();
        const nev = document.getElementById('nev').value;
        const kor = document.getElementById('kor').value;
        const email = document.getElementById('email').value;
  
        if (nev && kor && email) {
          localStorage.setItem('nev', nev);
          localStorage.setItem('kor', kor);
          localStorage.setItem('email', email);
          window.location.href = "szint-index.html";
        }
      });
    }
  
    if (document.getElementById('kartyak-lista')) {
      const level = localStorage.getItem('level');
      let cardCount = 8;
  
      if (level === 'medium') cardCount = 12;
      if (level === 'hard') cardCount = 16;
  
      totalCards = cardCount * 2;
  
      startTimer();
      generateCards(cardCount);
      
    }
  });
  
  function startGame(level) {
    localStorage.setItem('level', level);
    window.location.href = "jatek-index.html";
  }
  
  // Kartyak generalasa
  function generateCards(count) {
    const images = shuffle([...KepekLista.slice(0, count), ...KepekLista.slice(0, count)]);
    const ul = document.getElementById('kartyak-lista');
    ul.innerHTML = '';
  
    images.forEach((img) => {
      const li = document.createElement('li');
      li.classList.add('kartya');
      li.innerHTML = `
        <div class="kartya-elso"><img src="kepek/${img}.jpg" class="kartya-ertek" /></div>
        <div class="kartya-hatul">?</div>
      `;
      ul.appendChild(li);
    });
  
    // Felfedéskor
    document.querySelectorAll('.kartya').forEach(card => card.classList.add('flipped'));
    setTimeout(() => {
      document.querySelectorAll('.kartya').forEach(card => card.classList.remove('flipped'));
    }, 4000);
  
    
    ul.addEventListener('click', function (e) {
      const card = e.target.closest('.kartya');
      if (!card || card.classList.contains('flipped') || card.classList.contains('matched') || flippedCards.length >= 2) return;
  
      card.classList.add('flipped');
      flippedCards.push(card);
  
      if (flippedCards.length === 2) {
        setTimeout(checkMatch, 1000);
      }
    });
  }
  
  function checkMatch() {
    const [card1, card2] = flippedCards;
    const img1 = card1.querySelector('img').src;
    const img2 = card2.querySelector('img').src;
  
    if (img1 === img2) {
      card1.classList.add('matched');
      card2.classList.add('matched');
      matchedCards += 2;
    } else {
      card1.classList.remove('flipped');
      card2.classList.remove('flipped');
      hibak++;
      document.getElementById('hibak').textContent = hibak;
    }
  
    flippedCards = [];
  
    if (matchedCards === totalCards) {
      clearInterval(interval);
      saveStats();
      setTimeout(() => console.log('Gratulálok! Teljesítetted a játékot!'), 300);
    }
  }
  
  function shuffle(arr) {
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
  }
  
  function startTimer() {
    interval = setInterval(() => {
      timer++;
      document.getElementById('ido').textContent = timer;
    }, 1000);
  }
  
  // -------- STATISZTIKÁK --------
  function saveStats() {
    const stat = {
      email: localStorage.getItem('email'),
      kor: localStorage.getItem('kor'),
      szint: localStorage.getItem('level'),
      ido: timer,
      hibak,
      datum: new Date().toLocaleDateString()
    };
  
    const statok = JSON.parse(localStorage.getItem('statisztikak')) || [];
    statok.push(stat);
    localStorage.setItem('statisztikak', JSON.stringify(statok));
  }
  
  
  